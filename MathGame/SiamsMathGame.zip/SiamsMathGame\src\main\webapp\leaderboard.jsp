<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="model.GameScore" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top 10 Leaderboard - Siam's Math Game</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="header">
                <div class="brand-badge">
                    <span class="pulse-dot"></span>
                    Hall of Fame
                </div>
                <h1 class="title">Top 10 Leaderboard</h1>
                <p class="subtitle">Siam's Math Game &bull; Real-time Hall of Fame via JDBC</p>
                <div style="margin-top: 10px;">
                    <span class="badge badge-normal">Difficulty: NORMAL</span>
                </div>
            </div>

            <%
                List<GameScore> topScores = (List<GameScore>) request.getAttribute("topScores");
            %>

            <!-- Top 3 Podium Highlight (If scores exist) -->
            <% if (topScores != null && !topScores.isEmpty()) { %>
                <div class="podium-grid">
                    <%-- 2nd Place Card --%>
                    <% if (topScores.size() >= 2) { 
                        GameScore second = topScores.get(1);
                    %>
                        <div class="podium-card silver">
                            <div class="podium-medal">🥈</div>
                            <div class="podium-name"><%= second.getPlayerName() %></div>
                            <div class="podium-score"><%= second.getScore() %> <span style="font-size: 0.85rem; color: #94a3b8;">/ 10</span></div>
                            <span class="badge badge-normal" style="margin-top: 6px;">2nd Place</span>
                        </div>
                    <% } %>

                    <%-- 1st Place Card --%>
                    <% if (topScores.size() >= 1) { 
                        GameScore first = topScores.get(0);
                    %>
                        <div class="podium-card gold">
                            <div class="podium-medal">🥇</div>
                            <div class="podium-name"><%= first.getPlayerName() %></div>
                            <div class="podium-score"><%= first.getScore() %> <span style="font-size: 0.85rem; color: #94a3b8;">/ 10</span></div>
                            <span class="badge badge-normal" style="margin-top: 6px; border-color: rgba(250, 204, 21, 0.4); color: #facc15;">Champion</span>
                        </div>
                    <% } %>

                    <%-- 3rd Place Card --%>
                    <% if (topScores.size() >= 3) { 
                        GameScore third = topScores.get(2);
                    %>
                        <div class="podium-card bronze">
                            <div class="podium-medal">🥉</div>
                            <div class="podium-name"><%= third.getPlayerName() %></div>
                            <div class="podium-score"><%= third.getScore() %> <span style="font-size: 0.85rem; color: #94a3b8;">/ 10</span></div>
                            <span class="badge badge-normal" style="margin-top: 6px;">3rd Place</span>
                        </div>
                    <% } %>
                </div>
            <% } %>

            <!-- Detailed Leaderboard Table -->
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>Player Name</th>
                            <th>Score</th>
                            <th>Difficulty</th>
                            <th>Date &amp; Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <%
                            if (topScores != null && !topScores.isEmpty()) {
                                int rank = 1;
                                for (GameScore score : topScores) {
                                    String rankClass = "";
                                    String medal = "";
                                    if (rank == 1) { rankClass = "rank-1"; medal = "🥇 "; }
                                    else if (rank == 2) { rankClass = "rank-2"; medal = "🥈 "; }
                                    else if (rank == 3) { rankClass = "rank-3"; medal = "🥉 "; }
                        %>
                            <tr>
                                <td class="<%= rankClass %>" style="font-family: var(--font-mono);"><%= medal %><%= rank++ %></td>
                                <td><strong style="color: #f1f5f9;"><%= score.getPlayerName() %></strong></td>
                                <td><strong style="color: #38bdf8; font-family: var(--font-mono);"><%= score.getScore() %> / 10</strong></td>
                                <td><span class="badge badge-normal"><%= score.getDifficulty() %></span></td>
                                <td style="color: #94a3b8; font-size: 0.85rem; font-family: var(--font-mono);"><%= score.getPlayedAt() %></td>
                            </tr>
                        <%
                                }
                            } else {
                        %>
                            <tr>
                                <td colspan="5" style="text-align: center; color: #94a3b8; padding: 28px;">
                                    🚀 No score records registered in database yet. Be the first to conquer the board!
                                </td>
                            </tr>
                        <%
                            }
                        %>
                    </tbody>
                </table>
            </div>

            <div class="btn-group">
                <a href="index.jsp" class="btn btn-primary" style="flex: 1;">
                    <span>🎮</span>
                    <span>Play New Game Challenge</span>
                </a>
            </div>
        </div>
    </div>
</body>
</html>
