<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Siam's Math Game - Challenge</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <%
                int step = (Integer) session.getAttribute("currentStep");
                String phase = (String) session.getAttribute("phase"); // "input" or "quiz"
                String playerName = (String) session.getAttribute("playerName");
                int progress = (step - 1) * 25 + ("quiz".equals(phase) ? 15 : 5);
            %>

            <div class="header">
                <div class="brand-badge">
                    <span class="pulse-dot"></span>
                    Siam's Math Whiz
                </div>
                <h1 class="title">Siam's Math Game</h1>
                <p class="subtitle">Player: <strong><%= playerName %></strong> &bull; Challenge <strong><%= step %> of 4</strong></p>

                <!-- Modern Multi-Step Tracker -->
                <div class="stepper-container">
                    <div class="stepper-steps">
                        <div class="step-node <%= step > 1 ? "completed" : (step == 1 ? "active" : "") %>">
                            <div class="step-circle"><%= step > 1 ? "✓" : "1" %></div>
                            <span class="step-label">Prime</span>
                        </div>
                        <div class="step-node <%= step > 2 ? "completed" : (step == 2 ? "active" : "") %>">
                            <div class="step-circle"><%= step > 2 ? "✓" : "2" %></div>
                            <span class="step-label">Modulus</span>
                        </div>
                        <div class="step-node <%= step > 3 ? "completed" : (step == 3 ? "active" : "") %>">
                            <div class="step-circle"><%= step > 3 ? "✓" : "3" %></div>
                            <span class="step-label">Trig I</span>
                        </div>
                        <div class="step-node <%= step == 4 && "quiz".equals(phase) ? "active" : (step == 4 ? "active" : "") %>">
                            <div class="step-circle">4</div>
                            <span class="step-label">Trig II</span>
                        </div>
                    </div>
                    <div class="progress-track">
                        <div class="progress-fill" style="width: <%= progress %>%;"></div>
                    </div>
                </div>
            </div>

            <% if (request.getAttribute("error") != null) { %>
                <div class="error-msg">
                    <span>⚠️</span>
                    <span><%= request.getAttribute("error") %></span>
                </div>
            <% } %>

            <!-- ========================================== -->
            <!-- QUESTION 1: PRIME NUMBER                   -->
            <!-- ========================================== -->
            <% if (step == 1) { %>
                <div class="question-header">
                    <span class="q-title">
                        <span>🔢</span> Challenge 1: Prime Number
                    </span>
                    <span class="q-marks">2 Marks</span>
                </div>

                <% if ("input".equals(phase)) { %>
                    <!-- Step 1 Phase 1: Provide seed -->
                    <div class="info-callout">
                        <span>💡</span>
                        <span>Provide a seed number. Siam's Math engine will mutate it by a random offset (&plusmn;1..10) to test if the result is prime!</span>
                    </div>

                    <form action="game" method="post" style="margin-top: 18px;">
                        <input type="hidden" name="action" value="generate_q1">
                        <div class="form-group">
                            <label for="primeSeed">Enter Seed Number:</label>
                            <div class="hint">Type any positive integer (e.g. 17, 24, 31)</div>
                            <input type="number" id="primeSeed" name="primeSeed" class="form-control" placeholder="e.g. 17" required autofocus>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <span>Mutate &amp; Generate Challenge</span>
                            <span>🎲</span>
                        </button>
                    </form>

                <% } else { %>
                    <!-- Step 1 Phase 2: Choose 1 (Prime) or 0 (Not Prime) -->
                    <div class="highlight-box">
                        <p class="highlight-subtitle">Mutated target number (Seed + Random &plusmn;1..10):</p>
                        <div class="math-expression"><%= session.getAttribute("q1_val") %></div>
                        <p class="highlight-prompt">Is <%= session.getAttribute("q1_val") %> a Prime Number?</p>
                    </div>

                    <form action="game" method="post">
                        <input type="hidden" name="action" value="answer_q1">
                        <div class="mcq-container">
                            <label class="mcq-option">
                                <input type="radio" name="q1_answer" value="1" required>
                                <span class="mcq-label">
                                    <span class="opt-pill">YES</span>
                                    <span>1 &bull; Prime</span>
                                </span>
                            </label>
                            <label class="mcq-option">
                                <input type="radio" name="q1_answer" value="0" required>
                                <span class="mcq-label">
                                    <span class="opt-pill">NO</span>
                                    <span>0 &bull; Not Prime</span>
                                </span>
                            </label>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <span>Submit Answer &amp; Continue</span>
                            <span>➡️</span>
                        </button>
                    </form>
                <% } %>
            <% } %>

            <!-- ========================================== -->
            <!-- QUESTION 2: MODULUS OPERATION              -->
            <!-- ========================================== -->
            <% if (step == 2) { %>
                <div class="question-header">
                    <span class="q-title">
                        <span>➗</span> Challenge 2: Modulus Operation
                    </span>
                    <span class="q-marks">2 Marks</span>
                </div>

                <% if ("input".equals(phase)) { %>
                    <!-- Step 2 Phase 1: Provide seeds -->
                    <div class="info-callout">
                        <span>💡</span>
                        <span>Enter Dividend and Divisor seeds. The system mutates them to create a modulo challenge with 4 choices.</span>
                    </div>

                    <form action="game" method="post" style="margin-top: 18px;">
                        <input type="hidden" name="action" value="generate_q2">
                        <div class="grid-2">
                            <div class="form-group">
                                <label for="modSeedA">Dividend (Number A):</label>
                                <input type="number" id="modSeedA" name="modSeedA" class="form-control" placeholder="e.g. 23" required autofocus>
                            </div>
                            <div class="form-group">
                                <label for="modSeedB">Divisor (Number B):</label>
                                <input type="number" id="modSeedB" name="modSeedB" class="form-control" placeholder="e.g. 5" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <span>Generate Modulus MCQ</span>
                            <span>🎲</span>
                        </button>
                    </form>

                <% } else { %>
                    <!-- Step 2 Phase 2: Choose remainder from 4 MCQ options -->
                    <div class="highlight-box">
                        <p class="highlight-subtitle">Calculate remainder of the mutated expression:</p>
                        <div class="math-expression">
                            <%= session.getAttribute("q2_valA") %> % <%= session.getAttribute("q2_valB") %> = ?
                        </div>
                        <p class="highlight-prompt">Select the correct integer remainder:</p>
                    </div>

                    <form action="game" method="post">
                        <input type="hidden" name="action" value="answer_q2">
                        <div class="mcq-container">
                            <%
                                List<Integer> options = (List<Integer>) session.getAttribute("q2_options");
                                char optLetter = 'A';
                                for (Integer opt : options) {
                            %>
                                <label class="mcq-option">
                                    <input type="radio" name="q2_answer" value="<%= opt %>" required>
                                    <span class="mcq-label">
                                        <span class="opt-pill"><%= optLetter++ %></span>
                                        <span><%= opt %></span>
                                    </span>
                                </label>
                            <% } %>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <span>Submit Answer &amp; Continue</span>
                            <span>➡️</span>
                        </button>
                    </form>
                <% } %>
            <% } %>

            <!-- ========================================== -->
            <!-- QUESTION 3: TRIGONOMETRY 1                 -->
            <!-- ========================================== -->
            <% if (step == 3) { %>
                <div class="question-header">
                    <span class="q-title">
                        <span>📐</span> Challenge 3: Trigonometry (Challenge 1)
                    </span>
                    <span class="q-marks">3 Marks</span>
                </div>

                <% if ("input".equals(phase)) { %>
                    <!-- Step 3 Phase 1: Provide digit, operator, angle -->
                    <div class="info-callout">
                        <span>💡</span>
                        <span>Enter coefficient digit, select trigonometric operator, and specify angle in degrees.</span>
                    </div>

                    <form action="game" method="post" style="margin-top: 18px;">
                        <input type="hidden" name="action" value="generate_q3">
                        <div class="form-group">
                            <label for="trigDigit">Normal Digit (Multiplier):</label>
                            <input type="number" step="any" id="trigDigit" name="trigDigit" class="form-control" placeholder="e.g. 4" required autofocus>
                        </div>
                        <div class="grid-2">
                            <div class="form-group">
                                <label for="trigOp">Trig Operator:</label>
                                <select id="trigOp" name="trigOp" class="form-control" required>
                                    <option value="sin">sin (Sine)</option>
                                    <option value="cos">cos (Cosine)</option>
                                    <option value="tan">tan (Tangent)</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="trigAngle">Angle in Degrees (°):</label>
                                <input type="number" step="any" id="trigAngle" name="trigAngle" class="form-control" placeholder="e.g. 30" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <span>Generate Trig MCQ</span>
                            <span>🎲</span>
                        </button>
                    </form>

                <% } else { %>
                    <!-- Step 3 Phase 2: Choose answer from 4 MCQ options -->
                    <div class="highlight-box">
                        <p class="highlight-subtitle">Mutated coefficient expression:</p>
                        <div class="math-expression">
                            <%= session.getAttribute("q3_mutatedDigit") %> &times; <%= session.getAttribute("q3_op") %>(<%= session.getAttribute("q3_angle") %>°) = ?
                        </div>
                        <p class="highlight-prompt">Select the correct value (rounded to 2 decimal places):</p>
                    </div>

                    <form action="game" method="post">
                        <input type="hidden" name="action" value="answer_q3">
                        <div class="mcq-container">
                            <%
                                List<Double> options = (List<Double>) session.getAttribute("q3_options");
                                char optLetter = 'A';
                                for (Double opt : options) {
                            %>
                                <label class="mcq-option">
                                    <input type="radio" name="q3_answer" value="<%= opt %>" required>
                                    <span class="mcq-label">
                                        <span class="opt-pill"><%= optLetter++ %></span>
                                        <span><%= opt %></span>
                                    </span>
                                </label>
                            <% } %>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <span>Submit Answer &amp; Continue</span>
                            <span>➡️</span>
                        </button>
                    </form>
                <% } %>
            <% } %>

            <!-- ========================================== -->
            <!-- QUESTION 4: TRIGONOMETRY 2                 -->
            <!-- ========================================== -->
            <% if (step == 4) { %>
                <div class="question-header">
                    <span class="q-title">
                        <span>📐</span> Challenge 4: Trigonometry (Challenge 2)
                    </span>
                    <span class="q-marks">3 Marks</span>
                </div>

                <% if ("input".equals(phase)) { %>
                    <!-- Step 4 Phase 1: Provide digit, operator, angle -->
                    <div class="info-callout">
                        <span>💡</span>
                        <span>Final stage! Enter another multiplier digit, choose operator, and enter the angle.</span>
                    </div>

                    <form action="game" method="post" style="margin-top: 18px;">
                        <input type="hidden" name="action" value="generate_q4">
                        <div class="form-group">
                            <label for="trigDigit">Normal Digit (Multiplier):</label>
                            <input type="number" step="any" id="trigDigit" name="trigDigit" class="form-control" placeholder="e.g. 6" required autofocus>
                        </div>
                        <div class="grid-2">
                            <div class="form-group">
                                <label for="trigOp">Trig Operator:</label>
                                <select id="trigOp" name="trigOp" class="form-control" required>
                                    <option value="cos">cos (Cosine)</option>
                                    <option value="sin">sin (Sine)</option>
                                    <option value="tan">tan (Tangent)</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="trigAngle">Angle in Degrees (°):</label>
                                <input type="number" step="any" id="trigAngle" name="trigAngle" class="form-control" placeholder="e.g. 60" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <span>Generate Final Challenge</span>
                            <span>🎲</span>
                        </button>
                    </form>

                <% } else { %>
                    <!-- Step 4 Phase 2: Choose answer from 4 MCQ options -->
                    <div class="highlight-box">
                        <p class="highlight-subtitle">Mutated coefficient expression:</p>
                        <div class="math-expression">
                            <%= session.getAttribute("q4_mutatedDigit") %> &times; <%= session.getAttribute("q4_op") %>(<%= session.getAttribute("q4_angle") %>°) = ?
                        </div>
                        <p class="highlight-prompt">Select the correct value (rounded to 2 decimal places):</p>
                    </div>

                    <form action="game" method="post">
                        <input type="hidden" name="action" value="answer_q4">
                        <div class="mcq-container">
                            <%
                                List<Double> options = (List<Double>) session.getAttribute("q4_options");
                                char optLetter = 'A';
                                for (Double opt : options) {
                            %>
                                <label class="mcq-option">
                                    <input type="radio" name="q4_answer" value="<%= opt %>" required>
                                    <span class="mcq-label">
                                        <span class="opt-pill"><%= optLetter++ %></span>
                                        <span><%= opt %></span>
                                    </span>
                                </label>
                            <% } %>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <span>Finish &amp; View Result</span>
                            <span>🏁</span>
                        </button>
                    </form>
                <% } %>
            <% } %>

        </div>
    </div>
</body>
</html>
