<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Game Results - Siam's Math Game</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="header">
                <div class="brand-badge">
                    <span class="pulse-dot"></span>
                    Challenge Complete
                </div>
                <h1 class="title">Siam's Math Game</h1>
                <p class="subtitle">Performance &amp; Detailed Analysis</p>
                <div style="margin-top: 10px;">
                    <span class="badge badge-normal">Difficulty: NORMAL</span>
                </div>
            </div>

            <%
                int score = (Integer) session.getAttribute("totalScore");
                String playerName = (String) session.getAttribute("playerName");
                List<Map<String, Object>> history = (List<Map<String, Object>>) session.getAttribute("history");
            %>

            <!-- Score Showcase Banner -->
            <div class="score-banner">
                <div class="score-player">Player Tag: <strong><%= playerName %></strong></div>
                <div class="score-number"><%= score %><span class="score-out-of"> / 10</span></div>
                <div class="score-verdict">
                    <% 
                        if (score == 10) {
                            out.print("🌟 Master Whiz! Perfect 10 / 10 Score!");
                        } else if (score >= 7) {
                            out.print("👏 Outstanding Work! Great Mathematical Precision!");
                        } else if (score >= 4) {
                            out.print("👍 Solid Effort! Keep Sharpening Your Math Skills!");
                        } else {
                            out.print("💪 Keep Practicing! Give It Another Shot!");
                        }
                    %>
                </div>
                <div>
                    <span class="score-saved-chip">
                        <span>✅</span>
                        <span>Saved to MySQL Database via JDBC PreparedStatement</span>
                    </span>
                </div>
            </div>

            <!-- Detailed Question Breakdown -->
            <div style="margin-top: 24px;">
                <h3 style="font-size: 1.1rem; color: #f1f5f9; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                    <span>📊</span>
                    <span>Challenge Breakdown &amp; Solutions</span>
                </h3>
            </div>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Challenge</th>
                            <th>Problem</th>
                            <th>Your Answer</th>
                            <th>Expected</th>
                            <th>Status</th>
                            <th>Marks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <%
                            if (history != null) {
                                for (Map<String, Object> item : history) {
                                    boolean isCorrect = (Boolean) item.get("isCorrect");
                        %>
                            <tr>
                                <td><strong style="color: #e2e8f0;"><%= item.get("title") %></strong></td>
                                <td style="font-family: var(--font-mono); color: #38bdf8;"><%= item.get("problem") %></td>
                                <td style="font-family: var(--font-mono);"><%= item.get("userAns") %></td>
                                <td style="font-family: var(--font-mono); color: #a5b4fc;"><%= item.get("correctAns") %></td>
                                <td>
                                    <% if (isCorrect) { %>
                                        <span class="badge badge-success">✓ Correct</span>
                                    <% } else { %>
                                        <span class="badge badge-danger">✗ Incorrect</span>
                                    <% } %>
                                </td>
                                <td><strong style="color: <%= isCorrect ? "#34d399" : "#fb7185" %>;"><%= item.get("marks") %> / <%= item.get("maxMarks") %></strong></td>
                            </tr>
                        <%
                                }
                            }
                        %>
                    </tbody>
                </table>
            </div>

            <div class="btn-group">
                <a href="index.jsp" class="btn btn-primary" style="flex: 1;">
                    <span>🔄</span>
                    <span>Play Again</span>
                </a>
                <a href="game?action=leaderboard" class="btn btn-secondary" style="flex: 1;">
                    <span>🏆</span>
                    <span>Leaderboard</span>
                </a>
            </div>
        </div>
    </div>
</body>
</html>
