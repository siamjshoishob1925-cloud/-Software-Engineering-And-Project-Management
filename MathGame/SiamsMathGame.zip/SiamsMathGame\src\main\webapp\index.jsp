<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Siam's Math Game - Math Whiz</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="header">
                <div class="brand-badge">
                    <span class="pulse-dot"></span>
                    Interactive Web Application
                </div>
                <h1 class="title">Siam's Math Game</h1>
                <p class="subtitle">Live Lab Test #2 &bull; Jakarta Servlet, JSP &amp; MySQL JDBC Architecture</p>
                <div style="margin-top: 12px;">
                    <span class="badge badge-normal">⚡ Level: NORMAL &bull; Max Score: 10</span>
                </div>
            </div>

            <div class="features-grid">
                <div class="feature-pill">
                    <span class="feat-icon">🎲</span>
                    <strong>Dynamic Mutations</strong>
                    <div style="color: #94a3b8; font-size: 0.78rem; margin-top: 2px;">Values shift by &plusmn;1..10</div>
                </div>
                <div class="feature-pill">
                    <span class="feat-icon">📐</span>
                    <strong>4 Math Steps</strong>
                    <div style="color: #94a3b8; font-size: 0.78rem; margin-top: 2px;">Prime, Mod &amp; Trig MCQ</div>
                </div>
                <div class="feature-pill">
                    <span class="feat-icon">🏆</span>
                    <strong>Live Leaderboard</strong>
                    <div style="color: #94a3b8; font-size: 0.78rem; margin-top: 2px;">Saved instantly via JDBC</div>
                </div>
            </div>

            <form action="game" method="post">
                <input type="hidden" name="action" value="start">
                
                <div class="form-group">
                    <label for="playerName">Enter Your Gamer Tag / Name:</label>
                    <input type="text" id="playerName" name="playerName" class="form-control" 
                           placeholder="e.g. Siam" required autofocus autocomplete="name">
                </div>

                <button type="submit" class="btn btn-primary">
                    <span>Start Game Challenge</span>
                    <span>🚀</span>
                </button>
            </form>

            <div class="btn-group">
                <a href="game?action=leaderboard" class="btn btn-secondary" style="width: 100%;">
                    <span>🏆</span>
                    <span>View Top 10 Hall of Fame</span>
                </a>
            </div>
        </div>
    </div>
</body>
</html>
