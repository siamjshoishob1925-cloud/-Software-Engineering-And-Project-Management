// Intentionally has no @Component annotation.
// CampusBoot should skip this class during scanning.
public class ReportPrinter {
}
