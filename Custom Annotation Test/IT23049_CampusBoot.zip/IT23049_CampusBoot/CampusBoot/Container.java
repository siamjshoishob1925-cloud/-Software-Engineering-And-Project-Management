import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.LinkedHashMap;
import java.util.Map;

public class Container {
    // LinkedHashMap keeps beans in registration order.
    private final Map<String, Object> beans = new LinkedHashMap<>();

    public void scan(Class<?>... classes) {
        for (Class<?> clazz : classes) {
            if (!clazz.isAnnotationPresent(Component.class)) {
                System.out.println("[Container] Skipped: " + clazz.getSimpleName()
                        + " (no @Component)");
                continue;
            }

            Component component = clazz.getAnnotation(Component.class);
            String beanName = component.value();

            if (beanName.isEmpty()) {
                beanName = Character.toLowerCase(clazz.getSimpleName().charAt(0))
                        + clazz.getSimpleName().substring(1);
            }

            try {
                Constructor<?> constructor = clazz.getDeclaredConstructor();
                constructor.setAccessible(true);
                Object instance = constructor.newInstance();
                beans.put(beanName, instance);

                System.out.println("[Container] Registered: " + beanName
                        + " (" + clazz.getSimpleName() + ")");
            } catch (ReflectiveOperationException e) {
                throw new IllegalStateException(
                        "Could not create bean " + clazz.getName()
                                + ". A no-argument constructor is required.", e);
            }
        }
    }

    public void injectValues(Map<String, String> config) {
        for (Object bean : beans.values()) {
            Class<?> clazz = bean.getClass();

            for (Field field : clazz.getDeclaredFields()) {
                if (!field.isAnnotationPresent(Value.class)) {
                    continue;
                }

                Value valueAnnotation = field.getAnnotation(Value.class);
                String key = valueAnnotation.value();
                String configuredValue = config.get(key);

                if (configuredValue == null) {
                    throw new IllegalArgumentException(
                            "Missing configuration key: " + key);
                }

                try {
                    field.setAccessible(true);

                    if (field.getType() == String.class) {
                        field.set(bean, configuredValue);
                    } else if (field.getType() == int.class
                            || field.getType() == Integer.class) {
                        field.set(bean, Integer.parseInt(configuredValue));
                    } else {
                        throw new IllegalArgumentException(
                                "Unsupported @Value field type: " + field.getType().getName());
                    }

                    System.out.println("[Container] Injected: " + key + " -> "
                            + clazz.getSimpleName() + "." + field.getName());
                } catch (IllegalAccessException e) {
                    throw new IllegalStateException(
                            "Could not inject field " + field.getName(), e);
                } catch (NumberFormatException e) {
                    throw new IllegalArgumentException(
                            "Configuration value for '" + key
                                    + "' is not a valid integer: " + configuredValue, e);
                }
            }
        }
    }

    public Object getBean(String name) {
        return beans.get(name);
    }

    // Package-private access for Router to inspect all registered beans.
    Map<String, Object> getBeans() {
        return beans;
    }
}
