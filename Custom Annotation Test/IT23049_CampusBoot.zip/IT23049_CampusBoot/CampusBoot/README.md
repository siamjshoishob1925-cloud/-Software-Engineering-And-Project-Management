# CampusBoot — Java Reflection & Custom Annotations

A small Java 11+ framework demonstrating runtime annotations and reflection. It uses only the Java standard library.

## Project files

- `Component.java` — marks a class as a managed component.
- `Value.java` — marks a field for configuration injection.
- `Range.java` — declares an inclusive integer validation range.
- `Route.java` — maps a method to a URL path.
- `Container.java` — creates component instances and injects configuration.
- `Validator.java` — checks fields annotated with `@Range`.
- `Router.java` — finds and invokes a matching `@Route` method.
- `GradeController.java`, `ReportPrinter.java`, `Student.java` — assignment starter classes.
- `Main.java` — runs the demonstration.
- `answers.txt` — answers to the reflection questions.

## Run in a terminal

Install a JDK 11 or later, open a terminal in this folder, then run:

```bash
javac *.java
java Main
```

In IntelliJ IDEA, Eclipse, or NetBeans, create/open a Java project, place all `.java` files in the source folder, and run `Main`.

## How it works

1. Each custom annotation uses `@Retention(RetentionPolicy.RUNTIME)`, so reflection can inspect it while the program runs.
2. `Container.scan()` checks each class for `@Component`, creates an instance through its no-argument constructor, and stores it by bean name.
3. `Container.injectValues()` checks each bean's declared fields, reads `@Value`, looks up the config key, and assigns either a `String` or an `int`.
4. `Validator.validate()` reads `@Range` from fields and reports values outside the inclusive minimum and maximum.
5. `Router.dispatch()` searches registered beans for a matching `@Route` and invokes the method.

## Expected output

```text
[Container] Registered: gradeController (GradeController)
[Container] Skipped: ReportPrinter (no @Component)
[Container] Injected: app.name -> GradeController.appName
[Container] Injected: app.passMark -> GradeController.passMark
--- Validation ---
VIOLATION: score - Score must be between 0 and 100 (actual: 120)
OK
VIOLATION: semester - Value out of range (actual: 15)
--- Routing ---
[Router] /hello -> Welcome to CampusBoot
[Router] /status -> Pass mark is 40
[Router] /unknown -> 404 Not Found: /unknown
```

## Notes

- `LinkedHashMap` preserves bean registration order.
- The implementation follows the assignment's required no-argument constructor rule for components.
- `@Range` checks integer fields and treats both endpoints as valid.
- Route methods must have no parameters and return `String`, as required by the assignment.
