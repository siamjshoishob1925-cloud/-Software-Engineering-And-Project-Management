import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Router {
    public static String dispatch(Container container, String path) {
        for (Object bean : container.getBeans().values()) {
            for (Method method : bean.getClass().getDeclaredMethods()) {
                if (!method.isAnnotationPresent(Route.class)) {
                    continue;
                }

                Route route = method.getAnnotation(Route.class);
                if (route.path().equals(path)) {
                    if (method.getParameterCount() != 0
                            || method.getReturnType() != String.class) {
                        throw new IllegalStateException(
                                "Route method must take no parameters and return String: "
                                        + method.getName());
                    }

                    try {
                        method.setAccessible(true);
                        return (String) method.invoke(bean);
                    } catch (IllegalAccessException e) {
                        throw new IllegalStateException(
                                "Cannot access route method: " + method.getName(), e);
                    } catch (InvocationTargetException e) {
                        throw new IllegalStateException(
                                "Route method failed: " + method.getName(), e.getCause());
                    }
                }
            }
        }

        return "404 Not Found: " + path;
    }
}
